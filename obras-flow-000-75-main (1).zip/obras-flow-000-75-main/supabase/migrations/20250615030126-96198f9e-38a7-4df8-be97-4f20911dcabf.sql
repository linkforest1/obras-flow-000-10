
ALTER TABLE public.activities DROP CONSTRAINT IF EXISTS activities_status_check;
